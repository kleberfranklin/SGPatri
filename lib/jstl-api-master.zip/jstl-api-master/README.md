# Prerequisites

To build this project, Oracle JDK 1.7 is required. 

While JDK 1.7 allows the project to build despite Javadoc tags/params related warning, it fails with JDK 1.8.
